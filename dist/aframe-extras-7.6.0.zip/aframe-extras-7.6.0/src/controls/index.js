import './checkpoint-controls.js';
import './gamepad-controls.js';
import './keyboard-controls.js';
import './touch-controls.js';
import './movement-controls.js';
import './trackpad-controls.js';
import './nipple-controls.js';
