# rupee

https://sketchfab.com/models/0c8d66cf39e84c29b67a62fa11c40eba

By user [soiber](https://sketchfab.com/soiber) on Sketchfab.
