Author
======

This is the work of Emil Persson, aka Humus.
http://www.humus.name
humus@comhem.se



Legal stuff
===========

This work is free and may be used by anyone for any purpose
and may be distributed freely to anyone using any distribution
media or distribution method as long as this file is included.
Distribution without this file is allowed if it's distributed
with free non-commercial software; however, fair credit of the
original author is expected.
Any commercial distribution of this software requires the written
approval of Emil Persson.
